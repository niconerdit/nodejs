---

# CORRECTO! PIZZA ES LA ÚNICA COMIDA

Buen trabajo accediendo a esa propiedad.

El siguiente ejercicio es completamente acerca de **llaves de objetos**.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.

---
