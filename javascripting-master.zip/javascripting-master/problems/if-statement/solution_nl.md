---

# MASTER VAN CONDITIONALS

You got it! De string `orange` heeft meer dan vijf characters.

Zorg dat je klaar zit om met **for loops** aan de slag te gaan!

Run `javascripting` in de console om de volgende uitdaging te kiezen.

---
