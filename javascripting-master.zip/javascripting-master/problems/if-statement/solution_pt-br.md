---

# MESTRE DAS CONDICIONAIS!

Você entendeu a coisa toda! A string `orange` tem mais do que cinco caracteres.

Se prepare para **fazer loops com for**!

Execute `javascripting` no console para escolher o próximo desafio.

---
