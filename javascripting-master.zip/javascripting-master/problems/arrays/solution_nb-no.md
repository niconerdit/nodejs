---

# YAY, ET PIZZA ARRAY!

Du greide å lage et array!

I den neste oppgaven skal vi utforske filtrering av arrayer.

Kjør kommandoen `javascripting` i terminalen for å velge neste oppgave.

---
