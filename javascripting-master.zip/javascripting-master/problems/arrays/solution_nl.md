---

# YEET, EEN PIZZA ARRAY!

Je hebt met succes een array gemaakt!

In de volgende uitdaging gaan we kijken hoe we arrays kunt filteren.

Run `javascripting` in de console om de volgende uitdaging te kiezen.

---
