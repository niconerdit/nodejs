---

# EVVIVA, UN ARRAY DI PIZZA!

Hai creato con successo un array!

Nella prossima sfida esploreremo come filtrare gli array.

Esegui `javascripting` nella console per scegliere la prossima sfida.

---
