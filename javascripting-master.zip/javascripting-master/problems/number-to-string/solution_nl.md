---

# HET NUMMER IS NU EEN STRING!

Geweldig. Je hebt het nummer veranderd in een string!

In volgende uitdaging gaan we kijken naar **if statements**.

Run `javascripting` in de console om de volgende uitdaging te kiezen.

---
