---

# EL NÚMERO PASÓ A SER UNA STRING!

Excelente, ya sabemos cómo convertir cualquier número a string.

En el siguiente ejercicio echaremos un vistazo a los **bloques condicionales**.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.

---
