---

# ¡FILTRADO!

Buen trabajo filtrando ese array.

En el siguiente ejercicio estaremos trabajando con un ejemplo de cómo recorrer arrays.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.

---
