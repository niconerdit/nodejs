---

# FILTRÉ !

Vous avez réussi à filtrer le tableau.

Dans le défi suivant nous allons travailler sur un exemple d'accès aux valeurs d'un tableau.

Exécutez `javascripting` dans la console pour choisir le prochain défi.

---
