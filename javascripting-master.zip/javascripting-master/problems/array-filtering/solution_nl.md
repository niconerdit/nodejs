---

# GEFILTERD!

Goed bezig met het filteren van die array!

In de volgende uitdaging gaan werken met code die waarden uit een array haalt.

Run `javascripting` in de console om de volgende uitdaging te kiezen.

---
