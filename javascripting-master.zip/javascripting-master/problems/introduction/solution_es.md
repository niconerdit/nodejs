---

# LO HICISTE!

Todo lo que esté dentro de los paréntesis de `console.log()` será impreso a la terminal.

Entonces esto: 

```js
console.log('hola mundo')
```

imprime `hola mundo` a la terminal.

En particular, estamos imprimiendo una **string** o cadena de caracteres a la terminal: `hola mundo`.

En el siguiente ejercicio nos concentramos en aprender más acerca de **strings**.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.
