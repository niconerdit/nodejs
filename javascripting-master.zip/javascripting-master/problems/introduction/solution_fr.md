---

# VOUS AVEZ RÉUSSI !

Tout ce qui est entre les parenthèses de `console.log()` est affiché dans le terminal.

Donc :

```js
console.log('hello')
```

affiche `hello` dans le terminal.

Pour le moment nous affichons une **chaîne de caractères** dans le terminal : `hello`.

Dans le prochain défi, nous allons nous focaliser sur l'apprentissage des **variables**.

Exécutez `javascripting` dans la console pour choisir le prochain défi.
