---

# OOOOOH DES BANANES

Vous avez réussi ! Vous avez créé une fonction qui prend une entrée, la traite et renvoie une sortie.

Exécutez `javascripting` dans la console pour choisir le prochain défi.

---
