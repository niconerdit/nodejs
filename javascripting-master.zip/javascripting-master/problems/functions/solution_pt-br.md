---

# UHUUU! BANANAS!!!

Você conseguiu! Você criou uma função que recebe uma entrada, processa aquela entrada, e devolve uma saída.

Execute `javascripting` no console para escolher o próximo resultado.

---
