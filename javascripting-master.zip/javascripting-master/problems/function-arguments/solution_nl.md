---

# JE HEBT CONTROLE OVER JE ARGUMENTEN!

Complimenten voor het afronden van deze uitdaging.

Run `javascripting` in de console om de volgende uitdaging te kiezen.

---
