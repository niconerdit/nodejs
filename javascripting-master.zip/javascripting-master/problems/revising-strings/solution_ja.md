---

# pizza is wonderful です！

`.replace()` メソッドがいい感じです。

つづいて**数値**の探検をしましょう。

コンソールで `javascripting` コマンドを実行します。次の課題を選択しましょう。

---
