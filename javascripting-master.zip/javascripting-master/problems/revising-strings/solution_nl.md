---

# YES, PIZZA _IS_ HEERLIJK.

Knap gedaan met die `.replace()` method!

Nu gaan we verder met **numbers**.

Run `javascripting` in de console om de volgende uitdaging te kiezen.

---
