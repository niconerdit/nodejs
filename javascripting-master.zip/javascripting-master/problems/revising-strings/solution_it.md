---

# SÌ, LA PIZZA _È_ MERAVIGLIOSA.

Ben fatto con quel metodo `.replace()`!

Prossimamente esploreremo i **numeri**.

Esegui `javascripting` nella console per scegliere la prossima sfida.

---
