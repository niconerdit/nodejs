---

# O TOTAL É 45

Isto foi uma introdução bem básica aos loops, dos quais são úteis em várias situações, particularmente em combinação com outros tipos de dados como strings e arrays.

No próximo desafio começaremos á trabalhar com **arrays**.

Execute `javascripting` no console para escolher o próximo desafio.

---
