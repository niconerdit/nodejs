---

# EL TOTAL ES 45

Esta es una introducción básica al uso de for, lo cual es útil en muchas situaciones, particularmente en combinación con otras tipos de datos cómo arrays o strings.

En el siguiente ejercicio empezaremos a trabajar con **arrays**.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.

---
