---

# HET TOTAAL IS 45

Dit was een basis inleiding van for-loops, die in een aantal situaties handig zijn, vooral in combinatie met andere gegevenstypen zoals strings en arrays.

In de volgende uitdaging beginnen we met het gebruiken van **arrays**,

Run `javascripting` in de console om de volgende uitdaging te kiezen.

---
