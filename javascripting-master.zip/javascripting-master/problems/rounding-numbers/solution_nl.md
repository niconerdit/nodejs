---

# DAT GETAL IS AFGEROND

Yep, je hebt net een getal afgerond van `1.5` naar `2`. Lekker bezig.

In de volgende uitdaging gaan we een number in een string veranderen.

Run `javascripting` in de console om de volgende uitdaging te kiezen.

---
