---

# SUCCÈS ! PLEIN D'ANIMAUX !

Tous les éléments dans le tableau `pets` sont maintenant au pluriel !

Dans le prochain défi, nous allons découvrir les **objets**.

Exécutez `javascripting` dans la console pour choisir le prochain défi.

---
