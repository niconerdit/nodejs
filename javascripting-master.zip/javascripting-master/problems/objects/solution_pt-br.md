---

# O OBJETO PIZZA FOI UMA BOA!

Você criou um objeto com sucesso!

No próximo desafio vamos ver como fazemos para acessar as propriedades de um objeto.

Execute `javascripting` no console para escolher o próximo desafio.

---
