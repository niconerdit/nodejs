---

# SECOND ELEMENT OF ARRAY PRINTED!

Good job accessing that element of array.

In the next challenge we will work on an example of looping through arrays.

Run `javascripting` in the console to choose the next challenge.

---