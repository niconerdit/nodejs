---

# TWEEDE ELEMENT VAN DE ARRAY GEPRINT!

Goed gedaan om toegang te krijgen tot dat element van de array.

In de volgende uitdaging gaan we loopen door arrays

Run `javascripting` in de console om de volgende uitdaging te kiezen.

---