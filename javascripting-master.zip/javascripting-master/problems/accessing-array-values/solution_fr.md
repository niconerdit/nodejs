---

# DEUXIÈME ÉLÉMENT DU TABLEAU AFFICHÉ !

Vous avez réussi à accéder au second élément du tableau.

Dans le défi suivant nous allons travailler sur un exemple de boucle de parcours de tableaux.

Exécutez `javascripting` dans la console pour choisir le prochain défi.

---
