---

# VOCÊ IMPRIMIU O SEGUNDO ELEMENTO DO ARRAY!

Você realizou um bom trabalho ao acessar aquele elemento do array.

No próximo desafio vamos ver como fazer um loop pelos elementos do array.

Execute `javascripting` no console para escolher o próximo desafio.

---