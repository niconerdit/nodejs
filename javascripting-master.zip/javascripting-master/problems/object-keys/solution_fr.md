---

# CORRECT.

Bon travail avec la méthode du prototype Object.keys(). N'oubliez pas de l'utiliser lorsque vous devez lister les clés d'un objet.

Le prochain défi portera sur les **functions**.

Exécutez `javascripting` dans la console pour choisir le prochain défi.

---
