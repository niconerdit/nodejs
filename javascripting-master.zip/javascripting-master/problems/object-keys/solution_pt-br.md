---

# CORRETO.

Bom trabalho utilizando o método Object.keys(). Lembre-se de utilizar ele quando você precisar listas as propriedades de um objeto.

O próximo desafio será sobre **functions**.

Execute `javascripting` no console para escolher o próximo desafio.

---
