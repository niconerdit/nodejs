---

# CORRECT.

Good job using the Object.keys() prototype method. Remember to use it when you need to list the keys of an object.

The next challenge is all about **functions**.

Run `javascripting` in the console to choose the next challenge.

---
