---

# CORRECTO.

Buen trabajo usando el método Object.keys(). Recuerda usarlo cuando necesites listar las propiedades de un objeto.

El próximo ejercicio trabajaremos con **funciones**.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.

---
