---

# SE DER JA! NUMMER!

Kult, du fikk til å definere en variabel med nummeret `123456789`.

I den neste oppgaven skal vi endre nummer.

Kjør kommandoen `javascripting` i terminalen for å velge neste oppgave.

---
