O números podem ser inteiros como `2`, `14`, ou `4353`, ou podem ser decimais  
como `3.14`, `1.5`, ou `100.7893423`.

## Desafio:

Crie um arquivo chamado `numbers.js`.

No arquivo defina uma variável chamada `example` que referencia o valor `123456789`.

Use o `console.log()` para imprimir o número no terminal.

Verifique se o seu programa está correto executando o seguinte comando:

`javascripting verify numbers.js`
