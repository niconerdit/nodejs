---

# YEAH! NUMBERS!

Cool, you successfully defined a variable as the number `123456789`.

In the next challenge we will look at manipulating numbers.

Run `javascripting` in the console to choose the next challenge.

---
