---

# YEAH! NUMBERS!

Cool, je hebt met succes een number variabele gedefinieerd met het getal `123456789`.

In volgende uitdaging gaan we nummers aanpassen.

Run `javascripting` in de console om de volgende uitdaging te kiezen.

---
