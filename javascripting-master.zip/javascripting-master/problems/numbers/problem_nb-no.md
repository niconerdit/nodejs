Nummer kan være heltall, som `2`, `14` eller `4353`, eller de kan være desimaltall
også kjent som flyttall slik som `3.14`, `1.5` eller `100.7893423`.

## Oppgaven:

Lag en fil som heter `numbers.js`.

Definer en variabel `example` som referer heltallet `123456789` i den filen.

Brukt `console.log()` for å skrive nummeret til skjermen.

Se om programmet ditt er riktig ved å kjøre denne kommandoen:

`javascripting verify numbers.js`
