I numeri possono essere interi, come `2`, `14` o `4353`, o possono essere decimali,  
conosciuti anche come `float`, com `3.14`, `1.5` o `100.7893423`.
Diversamente dalle stringhe, i numeri non hanno bisogno di apici.

## La sfida:

Crea un file dal nome `numbers.js`.

In questo file definisci una variabile chiamata `example` che referenzia l'intero `123456789`.

Usa `console.log()` per stampare il numero sul terminale.

Verifica che il tuo programma sia corretto eseguendo questo comando:

`javascripting verify numbers.js`
