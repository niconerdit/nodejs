Los números pueden ser enteros, cómo `3`, `5` o `3337`, o pueden ser decimales,
cómo `3.14`, `1.5` o `100.7893423`.

## El ejercicio:

Crea un archivo llamado `numbers.js`.

En ese archivo define una variable llamada `ejemplo` qué referencie el entero `123456789`.

Utiliza `console.log()` para imprimir ese número a la terminal.

Comprueba si tu programa es correcto ejecutando el siguiente comando:

`javascripting verify numbers.js`
