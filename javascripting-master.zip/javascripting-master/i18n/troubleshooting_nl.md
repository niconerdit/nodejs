---
# Oeps, iets werkt nog niet.
# Maar... geen paniek! 
---

## Controleer je oplossing:

`Oplossing
===================`

%solution%

`Jouw oplossing
===================`

%attempt%

`Verschil
===================`

%diff%

## Aanvullende probleemoplossing::
 * Heb je de naam van het bestand correct getypt? Dit kun je controleren door dit command uit te voeren 'ls `%filename%`'. Als je dit ziet: 'ls: cannot access `%filename%`: No such file or directory,' bestaat het bestand misschien niet, heeft het een andere naam of bevindt het zich in een andere map.
 * Zorg ervoor dat je geen haakjes hebt weggelaten, anders kan de compiler het niet ontcijferen.
 * Zorg ervoor dat je geen typfouten in de tekst zelf hebt.

