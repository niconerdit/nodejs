__Trenger du hjelp?__ Se README-filen for denne workshopen: https://github.com/workshopper/javascripting
