__Потрібна допомога?__ Перегляньте README цього воркшопу: https://github.com/workshopper/javascripting
