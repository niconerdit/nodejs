__Hulp nodig? __ Lees de README voor deze workshop: https://github.com/workshopper/javascripting
