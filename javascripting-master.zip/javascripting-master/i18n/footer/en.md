__Need help?__ View the README for this workshop: https://github.com/workshopper/javascripting
