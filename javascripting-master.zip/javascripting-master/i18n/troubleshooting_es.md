---
# Ups, algo no está funcionando.
# Pero ¡Que no cunda el pánico! 
---

## Revisa tu solución:

`Solución
===================`

%solution%

`Tu intento
===================`

%attempt%

`Diferencia
===================`

%diff%

## Solución de problemas frecuentes:
 * ¿Escribiste correctamente el nombre del archivo? Lo puedes comprobar ejecutanto ls `%filename%`, si ves: ls: cannot access `%filename%`: No such file or directory entonces deberias crear un nuevo archivo, renombrar el existente o cambiar de carpeta a la que contenga el archivo
 * Asegúrate de no omitir paréntesis, ya que de otra manera el compilador no sería capaz de parsearlo.
 * Asegúrate de no cometer ningún tipo de error ortográfico
